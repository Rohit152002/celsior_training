﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalApplication.Models
{
    public class Specialist
    {
        public int SpecialistId { get; set; }
        public string SpecialistName { get; set; } = string.Empty;
    }
}
