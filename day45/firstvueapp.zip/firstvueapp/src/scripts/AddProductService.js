import axios from "axios";


export function AddProduct(name,  description, quantity,price, image) {
  console.log(name,  description, quantity,price, image);
  return axios.post('http://localhost:5243/api/Product',{

        "name": name,
        "description": description,
        "quantity": quantity,
        "pricePerUnit": price,
        "basicImage": image
  },
  {
    headers: {
      'Authorization': 'Bearer ' + sessionStorage.getItem('token')
    }
  });
}
